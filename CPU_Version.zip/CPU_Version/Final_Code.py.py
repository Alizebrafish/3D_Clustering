#Importing Libraries#

import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image, ImageTk

from sklearn.cluster import KMeans, Birch, SpectralClustering, MiniBatchKMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, f1_score, adjusted_rand_score, accuracy_score, davies_bouldin_score
from sklearn.preprocessing import LabelEncoder
from scipy.cluster.hierarchy import linkage, dendrogram
from mpl_toolkits.mplot3d import Axes3D


from sklearn.preprocessing import StandardScaler, MinMaxScaler
from scipy.stats import zscore
from sklearn.metrics import accuracy_score, adjusted_rand_score, normalized_mutual_info_score, f1_score

from tensorflow import keras
from keras.layers import Input, LSTM, RepeatVector, TimeDistributed, Input, Dense, Conv1D, GlobalMaxPooling1D
from keras.models import Model
from sklearn.model_selection import train_test_split
from keras.optimizers import Adam
from keras.utils import set_random_seed

import tkinter as tk
from tkinter import filedialog, messagebox
import os
from numba import jit, cuda

class ClusteringApp:
    
    def __init__(self, master):
        self.master = master
        self.master.title("Clustering Analysis App")
        self.master.iconbitmap("logo_image.ico")
        self.file_names = []
        self.subset_autoencoder = tk.DoubleVar(value=0.1)
        
        # Styling
        width = self.master.winfo_screenwidth()
        height = self.master.winfo_screenheight()
        
        self.master.geometry("%dx%d" % (width, height))
        #self.master.geometry("800x600")
        self.master.state("zoomed")
        self.master.configure(bg="#f0f0f0")
        self.master.option_add("*Font", "Helvetica 15")
        self.master.option_add("*Button.Background", "#4CAF50")
        self.master.option_add("*Button.Foreground", "#ffffff")
        
        # Load background image
        background_image = Image.open("background_img.jpg").resize((width, height), Image.LANCZOS)
        self.background_photo = ImageTk.PhotoImage(background_image)

        # Create a label to hold the background image
        self.background_label = tk.Label(image=self.background_photo)
        self.background_label.place(relwidth=1, relheight=1)
       
        # Create a label to hold the background image
        self.background_label = tk.Label(image=self.background_photo)
        self.background_label.place(relwidth=1, relheight=1)
        
        small_image = Image.open("details.png")
        small_image = small_image.resize((800, 270), Image.LANCZOS)
        small_tk_image = ImageTk.PhotoImage(small_image)
        small_label = tk.Label(image=small_tk_image)
        small_label.image = small_tk_image
        small_label.place(relx=0.5, rely=0.75, anchor="center")
        
        # GUI Components
        tk.Label(master, text="Input files number:", bg="#E4751B").grid(row=0, column=0, sticky="w", pady=(15, 5), padx=10)
        self.entry_num_files = tk.Entry(master)
        self.entry_num_files.grid(row=0, column=1, sticky="we", pady=(15, 5), padx=10)

        self.btn_generate_entries = tk.Button(master, text="Generate Entries", command=self.generate_entries)
        self.btn_generate_entries.grid(row=0, column=2, sticky="e", pady=5, padx=10)
        
        # Add button for plot output folder
        self.btn_plot_folder = tk.Button(master, text="Select Output Folder", command=self.browse_plot_folder)
        self.btn_plot_folder.grid(row=0, column=3, sticky="e", pady=5, padx=10)

        tk.Label(master, text="Autoencoder data split:", bg="#E4751B").grid(row=1, column=0, sticky="w", pady=5, padx=10)
        self.entry_subset_autoencoder = tk.Entry(master, textvariable=self.subset_autoencoder)
        self.entry_subset_autoencoder.grid(row=1, column=1, sticky="we", pady=5, padx=10)

        self.btn_results = tk.Button(master, text="Show Results", command=self.show_results)
        self.btn_results.grid(row=1, column=2, sticky="e", pady=5, padx=10)
        
        # Add text label
        self.text_label = tk.Label(master, text="Clustering 3D Data", bg="#E4751B", font=("Helvetica", 25))
        self.text_label.place(relx=0.5, rely=0.5, anchor="center")
        
        # Add text label
        self.text_label = tk.Label(master, text="Prof. Chung-Der Hsiao Lab", bg="#E4751B", font=("Helvetica", 20))
        self.text_label.place(relx=0.5, rely=1.0, anchor="s")

        
        self.entry_file_names = []
        self.btn_browse_files = []
        
        self.generate_entries()
        
        # Set the working directory to where the Python script is located
        script_dir = os.getcwd()
        os.chdir(script_dir)
        
        self.plot_folder = "plots"
        os.makedirs(self.plot_folder, exist_ok=True)
        
        self.plot_images = []
        
        # Add a seed for reproducibility
        self.seed = 55  # You can choose any integer as the seed
        random.seed(self.seed)
        np.random.seed(self.seed)
        set_random_seed(self.seed)  # Use Keras's utility function


    def generate_entries(self):
        num_files_str = self.entry_num_files.get()
        num_files = int(num_files_str) if num_files_str else 3  # Default value is 3

        # Remove existing entries and buttons
        for entry, btn in zip(self.entry_file_names, self.btn_browse_files):
            entry.grid_remove()
            btn.grid_remove()

        # Generate new entries and buttons based on the specified number of files
        self.entry_file_names = []
        self.btn_browse_files = []
        for i in range(num_files):
            tk.Label(self.master, text=f"Browse filename {i + 1}:", bg="#E4751B").grid(row=i + 2, column=0, sticky="w", pady=5, padx=10)
            entry_file_name = tk.Entry(self.master)
            entry_file_name.grid(row=i + 2, column=1, sticky="we", pady=5, padx=10)
            self.entry_file_names.append(entry_file_name)

            btn_browse = tk.Button(self.master, text=f"Browse file {i + 1}", command=lambda i=i: self.browse_file(i))
            btn_browse.grid(row=i + 2, column=2, sticky="e", pady=5, padx=10)
            self.btn_browse_files.append(btn_browse)

    def browse_file(self, index):
        self.file_names.append(filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")]))
        self.entry_file_names[index].delete(0, tk.END)
        self.entry_file_names[index].insert(0, self.file_names[index])
        messagebox.showinfo("File Selected", f"Selected File {index + 1}: {self.file_names[index]}")
    
    def browse_plot_folder(self):
        # Open a file dialog to browse the plot output folder
        plot_folder = filedialog.askdirectory()
        if plot_folder:
            # Update the plot folder variable and display it on the GUI if a folder is selected
            self.plot_folder = plot_folder
            messagebox.showinfo("Plot Output Folder", f"Selected Plot Output Folder: {self.plot_folder}")
    
    # Define methods to display different plots
    def display_elbow_plot(self):
        self.display_plot("Elbow Plot", f"{self.plot_folder}/elbow_plot.png", f"{self.plot_folder}/elbow_plot_EncodedData.png")

    def display_clusters_plot(self):
        self.display_plot("Clusters Plot", f"{self.plot_folder}/clustering_methods.png", f"{self.plot_folder}/clustering_methods_EncodedData.png")

    def display_silhouette_kmeans_plot(self):
        self.display_plot("Silhouette kmeans Plot", f"{self.plot_folder}/plot_class_scores_Silhouette_kmeans.png", f"{self.plot_folder}/plot_class_scores_Silhouette_kmeans_EncodedData.png")

    def display_silhouette_birch_plot(self):
        self.display_plot("Silhouette birch Plot", f"{self.plot_folder}/plot_class_scores_Silhouette_birch.png", f"{self.plot_folder}/plot_class_scores_Silhouette_birch_EncodedData.png")

    def display_silhouette_spectral_plot(self):
        self.display_plot("Silhouette spectral Plot", f"{self.plot_folder}/plot_class_scores_Silhouette_spectral.png", f"{self.plot_folder}/plot_class_scores_Silhouette_spectral_EncodedData.png")

    def display_silhouette_gmm_plot(self):
        self.display_plot("Silhouette gmm Plot", f"{self.plot_folder}/plot_class_scores_Silhouette_gmm.png", f"{self.plot_folder}/plot_class_scores_Silhouette_gmm_EncodedData.png")

    def display_davies_bouldin_kmeans_plot(self):
        self.display_plot("Davies Bouldin kmeans Plot", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_kmeans.png", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_kmeans_EncodedData.png")

    def display_davies_bouldin_birch_plot(self):
        self.display_plot("Davies Bouldin birch Plot", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_birch.png", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_birch_EncodedData.png")

    def display_davies_bouldin_spectral_plot(self):
        self.display_plot("Davies Bouldin spectral Plot", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_spectral.png", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_spectral_EncodedData.png")

    def display_davies_bouldin_gmm_plot(self):
        self.display_plot("Davies Bouldin gmm Plot", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_gmm.png", f"{self.plot_folder}/plot_class_scores_Davies Bouldin_gmm_EncodedData.png")

    def display_cross_clusters_silhouette_plot(self):
        self.display_plot("Cross Clusters Silhouette Plot", f"{self.plot_folder}/cross_cluster_plots_Silhouette.png", f"{self.plot_folder}/cross_cluster_plots_Silhouette_EncodedData.png")

    def display_cross_clusters_davies_plot(self):
        self.display_plot("Cross Clusters Davies Bouldin Plot", f"{self.plot_folder}/cross_cluster_plots_Davies.png", f"{self.plot_folder}/cross_cluster_plots_Davies_EncodedData.png")
    
    def display_dendrogram_silhouette(self):
        self.display_plot("Dendrogram Silhouette", f"{self.plot_folder}/dendrogram_Silhouette_scores.png", f"{self.plot_folder}/dendrogram_Silhouette_scores_EncodedData.png")

    def display_dendrogram_davies(self):
        self.display_plot("Dendrogram Davies Bouldin", f"{self.plot_folder}/dendrogram_Davies_scores.png", f"{self.plot_folder}/dendrogram_Davies_scores_EncodedData.png")
    
    
    def display_plot(self, button_name, before_encoding_filename, after_encoding_filename):
        # Clear any existing title_label
        for widget in self.result_window.winfo_children():
            if isinstance(widget, tk.Label) and widget.grid_info().get("row") == 7 and widget.grid_info().get("column") == 1:
                widget.destroy()
                
        # Add title label with the button name
        title_label = tk.Label(self.result_window, text=button_name, font=('Helvetica', 14, 'bold'))
        title_label.grid(row=7, column=1, padx=10)
    
        # Load the images
        before_encoding_image = Image.open(before_encoding_filename)
        after_encoding_image = Image.open(after_encoding_filename)
    
        # Resize images as needed
        before_encoding_image = before_encoding_image.resize((370, 370), Image.LANCZOS)
        after_encoding_image = after_encoding_image.resize((370, 370), Image.LANCZOS)
    
        # Convert images to Tkinter format
        before_encoding_tk_image = ImageTk.PhotoImage(before_encoding_image)
        after_encoding_tk_image = ImageTk.PhotoImage(after_encoding_image)
    
        # Create labels to display the images
        before_encoding_label = tk.Label(image=before_encoding_tk_image)
        before_encoding_label.image = before_encoding_tk_image  # To prevent garbage collection
        before_encoding_label.grid(row=10, column=0, padx=10)
    
        after_encoding_label = tk.Label(image=after_encoding_tk_image)
        after_encoding_label.image = after_encoding_tk_image  # To prevent garbage collection
        after_encoding_label.grid(row=10, column=2, padx=10)
        
    def save_clustering_results(self, silhouette_scores, davies_scores, data_type="before"):
        """
        Save clustering results to CSV files
        
        Parameters:
        silhouette_scores: numpy array of silhouette scores for different methods
        davies_scores: numpy array of davies bouldin scores for different methods
        data_type: string indicating if results are before or after encoding ("before" or "after")
        """
        # Get method names and file names
        methods = ["KMeans", "Birch", "GMM", "Spectral"]
        file_names = [os.path.splitext(os.path.basename(file))[0] for file in self.file_names]
        
        # Create DataFrame for class-wise scores
        class_scores = []
        for i in range(len(file_names)):
            row = {
                'Dataset': file_names[i],
                'KMeans_Silhouette': silhouette_scores[i,0],
                'Birch_Silhouette': silhouette_scores[i,1],
                'GMM_Silhouette': silhouette_scores[i,2],
                'Spectral_Silhouette': silhouette_scores[i,3],
                'KMeans_Davies': davies_scores[i,0],
                'Birch_Davies': davies_scores[i,1],
                'GMM_Davies': davies_scores[i,2],
                'Spectral_Davies': davies_scores[i,3]
            }
            class_scores.append(row)
        
        df_class = pd.DataFrame(class_scores)
        
        # Create DataFrame for method-wise average scores
        method_scores = {
            'Method': methods,
            'Avg_Silhouette': np.mean(silhouette_scores, axis=0),
            'Avg_Davies': np.mean(davies_scores, axis=0)
        }
        df_method = pd.DataFrame(method_scores)
        
        # Save to CSV with timestamp to prevent overwriting
        timestamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
        df_class.to_csv(f"{self.plot_folder}/class_scores_{data_type}_{timestamp}.csv", index=False)
        df_method.to_csv(f"{self.plot_folder}/method_scores_{data_type}_{timestamp}.csv", index=False)

    def subset_data_consistently(self, data, subset_percentage):
        """Select consistent data subset"""
        np.random.seed(55)  # Set seed for reproducibility
        subset_size = int(subset_percentage * len(data))
        indices = np.random.choice(len(data), subset_size, replace=False)
        return data.iloc[indices]
    
    
    def show_results(self):
        if not all(self.file_names):
            messagebox.showwarning("Warning", "Please select input files.")
            return
        
        dfs = []
            
        # Loop through each file and its corresponding label
        for file_name, label in zip(self.file_names, self.file_names):
            xls = pd.ExcelFile(file_name)
            for sheet_name in xls.sheet_names:
                df = xls.parse(sheet_name)
                df = df.iloc[:, :3]
                df.columns = ['X', 'Y', 'Z']
                df['label'] = label  # Add label column
                
                dfs.append(df)
        
        concatenated_data = pd.concat(dfs, ignore_index=True)
        
        # Save concatenated_data as CSV in self.plot_folder
        csv_filename = os.path.join(self.plot_folder, 'concatenated_data.csv')
        concatenated_data.to_csv(csv_filename, index=False)
        
        # Data Pre-processing
        #1. Dropping NaN values
        #2. Removing Outliers
        #3. Normalization#
        
        def DataPreprocessing(subset_data):
          z_scores = np.abs(zscore(subset_data))
          # Set a Z-score threshold for outlier removal
          threshold = 3  # Adjust as needed
          # Identify rows where all Z-scores are below the threshold
          rows_to_keep = (z_scores < threshold).all(axis=1)
          # Apply the mask to keep non-outlier rows
          subset_data = subset_data[rows_to_keep]
        
          #Data Normalization using a standard scaler
          scaler = StandardScaler()
        
          # Fit and transform the features
          normalized_features = scaler.fit_transform(subset_data)
        
          # Create a new DataFrame with normalized features
          data_for_clustering = pd.DataFrame(normalized_features, columns=subset_data.columns)
        
          return data_for_clustering, rows_to_keep
        
        # Selecting the data percentage for clustering analysis#
        
        subset_percentage = 0.01
        subset_data = self.subset_data_consistently(concatenated_data, subset_percentage)   
        subset_data = subset_data.dropna()
        data_for_clustering = subset_data[['X', 'Y', 'Z']]
        data_for_clustering, rows_to_keep = DataPreprocessing(data_for_clustering)
        labels = subset_data.label[rows_to_keep]
        label_encoder = LabelEncoder()
        Labels = label_encoder.fit_transform(labels)
        
        np.shape(Labels)
        
        # Determining the Optimal Number of Clusters using Elbow Method#
        def Generate_Elbow(data, encoded_bool):
          num_clusters_range = range(1, 11)
        
          wcss = []
        
          # Loop through different cluster numbers and fit KMeans models
          for num_clusters in num_clusters_range:
              kmeans = KMeans(n_clusters=num_clusters)
              kmeans.fit(data)
              wcss.append(kmeans.inertia_)  # Inertia is the WCSS value for that model
        
          # Plot the Elbow Method graph
          plt.figure(figsize=(10, 6))
          plt.plot(num_clusters_range, wcss, marker='o')
          plt.title('Elbow Method')
          plt.xlabel('Number of Clusters')
          plt.ylabel('Within-Cluster Sum of Squares (WCSS)')
          #plt.show()
          
          if encoded_bool== False:
              # Save plot to a folder
              plt.savefig(f"{self.plot_folder}/elbow_plot.png")
              plt.close()
    
          else:
              # Save plot to a folder
              plt.savefig(f"{self.plot_folder}/elbow_plot_EncodedData.png")
              plt.close()
    
        Generate_Elbow(data_for_clustering, False)
        
        # Getting the Scores#
        
        def Generate_Scores(data, labels):
          silhouette_avg = silhouette_score(data, labels)
          davies_bouldin = davies_bouldin_score(data, labels)
        
          return silhouette_avg, davies_bouldin
        
        def ClusteringMethods(data_for_clustering, n_clusters, clustering=True):
        
          # Set random seed
          np.random.seed(55)
          
          # Creating Clusters and Determining Clustering Scores#
          kmeans = KMeans(n_clusters=n_clusters, n_init=10, random_state=55)
          kmeans_labels = kmeans.fit_predict(data_for_clustering)
          silhouette_k, davies_bouldin_k = Generate_Scores(data_for_clustering, kmeans_labels)

          birch = Birch(n_clusters=n_clusters, threshold=0.01)
          birch_labels = birch.fit_predict(data_for_clustering)
          silhouette_b, davies_bouldin_b = Generate_Scores(data_for_clustering, birch_labels)

          gmm = GaussianMixture(n_components=n_clusters, n_init=10, random_state=55)
          gmm_labels = gmm.fit_predict(data_for_clustering)
          silhouette_gmm, davies_bouldin_gmm = Generate_Scores(data_for_clustering, gmm_labels)

          spectral = SpectralClustering(n_clusters=n_clusters, n_init=10, random_state=55, affinity='rbf')
          spectral_labels = spectral.fit_predict(data_for_clustering)
          silhouette_spec, davies_bouldin_spec = Generate_Scores(data_for_clustering, spectral_labels)

        
          if clustering == True:
            data_for_clustering = np.array(data_for_clustering)
            fig = plt.figure(figsize=(12, 12))
        
            ax1 = fig.add_subplot(221, projection='3d')
            for i, label in enumerate(np.unique(kmeans_labels)):
                mask = kmeans_labels == label
                ax1.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax1.set_title('KMeans')
            ax1.set_xlabel('X')
            ax1.set_ylabel('Y')
            ax1.set_zlabel('Z')
            ax1.legend()
        
            ax2 = fig.add_subplot(222, projection='3d')
            for i, label in enumerate(np.unique(birch_labels)):
                mask = birch_labels == label
                ax2.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax2.set_title('Birch')
            ax2.set_xlabel('X')
            ax2.set_ylabel('Y')
            ax2.set_zlabel('Z')
            ax2.legend()
        
            ax3 = fig.add_subplot(223, projection='3d')
            for i, label in enumerate(np.unique(gmm_labels)):
                mask = gmm_labels == label
                ax3.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax3.set_title('GMM')
            ax3.set_xlabel('X')
            ax3.set_ylabel('Y')
            ax3.set_zlabel('Z')
            ax3.legend()
        
            ax4 = fig.add_subplot(224, projection='3d')
            for i, label in enumerate(np.unique(spectral_labels)):
                mask = spectral_labels == label
                ax4.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax4.set_title('Spectral')
            ax4.set_xlabel('X')
            ax4.set_ylabel('Y')
            ax4.set_zlabel('Z')
            ax4.legend()
        
            plt.tight_layout()
            #plt.show()
            
            # Save plot to a folder
            plt.savefig(f"{self.plot_folder}/clustering_methods.png")
            plt.close()
      
          return silhouette_k, davies_bouldin_k, silhouette_b, davies_bouldin_b, silhouette_gmm, davies_bouldin_gmm, silhouette_spec, davies_bouldin_spec
        
        def ClusteringMethodsEncodedData(data_for_clustering, n_clusters, clustering = True):
        
          # Set random seed
          np.random.seed(55)
          
          # Creating Clusters and Determining Clustering Scores#
          kmeans = KMeans(n_clusters=n_clusters, n_init=10, random_state=55)
          kmeans_labels = kmeans.fit_predict(data_for_clustering)
          silhouette_k, davies_bouldin_k = Generate_Scores(data_for_clustering, kmeans_labels)

          birch = Birch(n_clusters=n_clusters, threshold=0.01)
          birch_labels = birch.fit_predict(data_for_clustering)
          silhouette_b, davies_bouldin_b = Generate_Scores(data_for_clustering, birch_labels)

          gmm = GaussianMixture(n_components=n_clusters, n_init=10, random_state=55)
          gmm_labels = gmm.fit_predict(data_for_clustering)
          silhouette_gmm, davies_bouldin_gmm = Generate_Scores(data_for_clustering, gmm_labels)

          spectral = SpectralClustering(n_clusters=n_clusters, n_init=10, random_state=55, affinity='rbf')
          spectral_labels = spectral.fit_predict(data_for_clustering)
          silhouette_spec, davies_bouldin_spec = Generate_Scores(data_for_clustering, spectral_labels)
          
          if clustering == True:
            data_for_clustering = np.array(data_for_clustering)
            fig = plt.figure(figsize=(12, 12))
        
            ax1 = fig.add_subplot(221, projection='3d')
            for i, label in enumerate(np.unique(kmeans_labels)):
                mask = kmeans_labels == label
                ax1.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax1.set_title('KMeans')
            ax1.set_xlabel('X Encoded')
            ax1.set_ylabel('Y Encoded')
            ax1.set_zlabel('Z Encoded')
            ax1.legend()
        
            ax2 = fig.add_subplot(222, projection='3d')
            for i, label in enumerate(np.unique(birch_labels)):
                mask = birch_labels == label
                ax2.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax2.set_title('Birch')
            ax2.set_xlabel('X Encoded')
            ax2.set_ylabel('Y Encoded')
            ax2.set_zlabel('Z Encoded')
            ax2.legend()
        
            ax3 = fig.add_subplot(223, projection='3d')
            for i, label in enumerate(np.unique(gmm_labels)):
                mask = gmm_labels == label
                ax3.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax3.set_title('GMM')
            ax3.set_xlabel('X Encoded')
            ax3.set_ylabel('Y Encoded')
            ax3.set_zlabel('Z Encoded')
            ax3.legend()
        
            ax4 = fig.add_subplot(224, projection='3d')
            for i, label in enumerate(np.unique(spectral_labels)):
                mask = spectral_labels == label
                ax4.scatter(data_for_clustering[mask, 0], data_for_clustering[mask, 1], data_for_clustering[mask, 2], label=os.path.splitext(os.path.basename(self.file_names[i]))[0])
            ax4.set_title('Spectral')
            ax4.set_xlabel('X Encoded')
            ax4.set_ylabel('Y Encoded')
            ax4.set_zlabel('Z Encoded')
            ax4.legend()
        
            plt.tight_layout()
            #plt.show()
            
            # Save plot to a folder
            plt.savefig(f"{self.plot_folder}/clustering_methods_EncodedData.png")
            plt.close()
      
          return silhouette_k, davies_bouldin_k, silhouette_b, davies_bouldin_b, silhouette_gmm, davies_bouldin_gmm, silhouette_spec, davies_bouldin_spec
        
        
        n_clusters = int(len(self.file_names))
        
        silhouette_scores = []
        davies_scores = []
        for i_label in range(len(np.unique(Labels))):
            data_with_label = data_for_clustering[Labels == i_label]
            if i_label == 0:
              clustering = True
            else:
              clustering = False
            silhouette_k, davies_bouldin_k, silhouette_b, davies_bouldin_b, silhouette_gmm, davies_bouldin_gmm, silhouette_spec, davies_bouldin_spec = ClusteringMethods(data_with_label, n_clusters, clustering = clustering)
        
            silhouette_scores.append([silhouette_k, silhouette_b, silhouette_gmm, silhouette_spec])
            davies_scores.append([davies_bouldin_k, davies_bouldin_b, davies_bouldin_gmm, davies_bouldin_spec])
        
        def PlotClassScores(scores, type, method, encoded_bool):
          methods = [os.path.splitext(os.path.basename(file_path))[0] for file_path in self.file_names]
          colors = ['blue', 'orange', 'green', 'red', 'purple', 'brown', 'pink', 'gray', 'cyan', 'magenta', 'olive', 'teal']
          # Create a bar graph
          plt.figure(figsize=(10, 6))
          plt.bar(methods, scores, color=colors[0:len(methods)])
          plt.title(type + ' Scores for ' + method + ' Clustering')
          plt.xlabel('Classes')
          plt.ylabel(type + ' Score')
          plt.ylim(0, np.max(scores) + 0.1)  # Set the y-axis limit as needed
          #plt.show()
          
          if encoded_bool== False:
              # Save plot to a folder
              plt.savefig(f"{self.plot_folder}/plot_class_scores_{type}_{method}.png")
              plt.close()
        
          else:
              # Save plot to a folder
              plt.savefig(f"{self.plot_folder}/plot_class_scores_{type}_{method}_EncodedData.png")
              plt.close()
                       
        
        def CrossClusterPlots(scores, type, encoded_bool):
            methods = ['kMeans', 'Birch', 'Gmm', 'Spectral']
            colors = ['blue', 'orange', 'green', 'red']
        
            # Create a bar graph
            plt.figure(figsize=(10, 6))
            plt.bar(methods, scores, color=colors)
            plt.title(type + ' Scores for Different Clustering Methods')
            plt.xlabel('Clustering Methods')
            plt.ylabel(type + ' Score')
            plt.ylim(0, np.max(scores) + 0.1)  # Set the y-axis limit as needed
            #plt.show()
            
            if encoded_bool== False:
                # Save plot to a folder
                plt.savefig(f"{self.plot_folder}/cross_cluster_plots_{type}.png")
                plt.close()
          
            else:
                # Save plot to a folder
                plt.savefig(f"{self.plot_folder}/cross_cluster_plots_{type}_EncodedData.png")
                plt.close()
          
        
        silhouette_scores = np.array(silhouette_scores)
        davies_scores = np.array(davies_scores)
        
        PlotClassScores(silhouette_scores[:,0], 'Silhouette', 'kmeans', False)
        PlotClassScores(silhouette_scores[:,1], 'Silhouette', 'birch', False)
        PlotClassScores(silhouette_scores[:,2], 'Silhouette', 'gmm', False)
        PlotClassScores(silhouette_scores[:,3], 'Silhouette', 'spectral', False)
        
        
        PlotClassScores(davies_scores[:,0], 'Davies Bouldin', 'kmeans', False)
        PlotClassScores(davies_scores[:,1], 'Davies Bouldin', 'birch', False)
        PlotClassScores(davies_scores[:,2], 'Davies Bouldin', 'gmm', False)
        PlotClassScores(davies_scores[:,3], 'Davies Bouldin', 'spectral', False)
        
        CrossClusterPlots(np.mean(silhouette_scores, axis = 0), 'Silhouette', False)
        CrossClusterPlots(np.mean(davies_scores, axis = 0), 'Davies', False)
        
        # Compute the linkage matrix
        linkage_matrix = linkage(davies_scores.T, method='ward')  # You can choose a different method if needed
        
        # Plot the dendrogram
        dendrogram(linkage_matrix, labels=["KMeans", "Birch", "GMM", "Spectral"])
        
        plt.title('Dendrogram based on Davies Scores')
        plt.xlabel('Clustering Algorithms')
        plt.ylabel('Distance')
        #plt.show()
        
        # Save plot to a folder
        plt.savefig(f"{self.plot_folder}/dendrogram_Davies_scores.png")
        plt.close()
        
        # Plot the dendrogram
        linkage_matrix = linkage(silhouette_scores.T, method='ward')  # You can choose a different method if needed
        dendrogram(linkage_matrix, labels=["KMeans", "Birch", "GMM", "Spectral"])
        
        plt.title('Dendrogram based on Silhouette Scores')
        plt.xlabel('Clustering Algorithms')
        plt.ylabel('Distance')
        #plt.show()
        
        # Save plot to a folder
        plt.savefig(f"{self.plot_folder}/dendrogram_Silhouette_scores.png")
        plt.close()
        
        # Save results before encoding
        self.save_clustering_results(silhouette_scores, davies_scores, "before")
        
        # Selecting the data percentage for Autoencoder analysis#
        
        #subset_percentage = 0.1
        subset_size = int(self.subset_autoencoder.get() * len(concatenated_data))
        subset_data = concatenated_data.sample(n=subset_size, random_state=55)
        subset_data = subset_data.dropna()
        data_for_encoding = subset_data[['X', 'Y', 'Z']]
        data_for_encoding, rows_to_keep = DataPreprocessing(data_for_encoding)
        data_for_encoding = np.array(data_for_encoding)
        labels = subset_data.label[rows_to_keep]
        label_encoder = LabelEncoder()
        Labels = label_encoder.fit_transform(labels)
        
        data_for_encoding
        
        # Convert the NumPy array to a Pandas DataFrame
        data_for_encoding_df = pd.DataFrame(data_for_encoding, columns=['X', 'Y', 'Z'])

        # Save data_for_encoding as CSV in self.plot_folder
        csv_file_name = os.path.join(self.plot_folder, 'data_for_encoding.csv')
        data_for_encoding_df.to_csv(csv_file_name, index=False)
        
        data_size = (data_for_encoding.shape[1], 1)
        code_size = 3  # Adjust this based on your desired code size
        
        #@jit(target_backend="cuda")
        def build_conv1d_pca_autoencoder(data_size, code_size):
            encoder = keras.models.Sequential()
            encoder.add(Conv1D(16, kernel_size=1, activation="relu", input_shape=data_size))
            encoder.add(Conv1D(32, kernel_size=1, activation="relu"))
            encoder.add(GlobalMaxPooling1D())
            encoder.add(Dense(code_size, activation="relu"))
        
            decoder = keras.models.Sequential()
            decoder.add(Dense(32, activation="relu", input_shape=(code_size,)))
            # decoder.add(Dense(16, activation="relu"))
            decoder.add(Dense(16, activation="relu"))
            decoder.add(Dense(np.prod(data_size), activation="softmax"))
            return encoder, decoder
        
        encoder, decoder = build_conv1d_pca_autoencoder(data_size, code_size)
        
        inp = Input(data_size)
        code = encoder(inp)
        reconstruction = decoder(code)
        
        autoencoder = keras.models.Model(inputs=inp, outputs=reconstruction)
        
        learning_rate = 1e-3
        optimizer = Adam(learning_rate=learning_rate)
        autoencoder.compile(loss='mse', optimizer=optimizer)
        
        autoencoder.fit(x=data_for_encoding, y=data_for_encoding, epochs=5, batch_size=16,
                        validation_split=0.2, verbose=1)
        
        # Encode the data using the trained encoder
        encoded_data = encoder.predict(data_for_encoding)
        
        # Convert the NumPy array to a Pandas DataFrame
        encoded_data_df = pd.DataFrame(encoded_data, columns=['X', 'Y', 'Z'])

            
        # Save data_for_encoding as CSV in self.plot_folder
        csv_file_name = os.path.join(self.plot_folder, 'encoded_data.csv')
        encoded_data_df.to_csv(csv_file_name, index=False)
        
        subset_size = int(0.1 * len(encoded_data))
        
        if subset_size > len(encoded_data):
            raise ValueError("Subset size is larger than the size of encoded_data.")
        
        # Generate random indices to select data points
        random_indices = np.random.choice(len(Labels), subset_size, replace=False)
        
        # Select the subset of data
        if len(random_indices) > 0:
            data_for_clustering = encoded_data[random_indices]
            Labels = Labels[random_indices]
        else:
            print("No data points selected. Please check your subset size and data size.")
        
        
        Generate_Elbow(data_for_clustering, True)
        
        n_clusters = int(len(self.file_names))
        
        silhouette_scores = []
        davies_scores = []
        for i_label in range(len(np.unique(Labels))):
            data_with_label = data_for_clustering[Labels == i_label]
            if i_label == 0:
              clustering = True
            else:
              clustering = False
            silhouette_k, davies_bouldin_k, silhouette_b, davies_bouldin_b, silhouette_gmm, davies_bouldin_gmm, silhouette_spec, davies_bouldin_spec = ClusteringMethodsEncodedData(data_with_label, n_clusters, clustering = clustering)
            
            silhouette_scores.append([silhouette_k, silhouette_b, silhouette_gmm, silhouette_spec])
            davies_scores.append([davies_bouldin_k, davies_bouldin_b, davies_bouldin_gmm, davies_bouldin_spec])
        
        silhouette_scores = np.array(silhouette_scores)
        davies_scores = np.array(davies_scores)
            
        
        PlotClassScores(silhouette_scores[:,0], 'Silhouette', 'kmeans', True)
        PlotClassScores(silhouette_scores[:,1], 'Silhouette', 'birch', True)
        PlotClassScores(silhouette_scores[:,2], 'Silhouette', 'gmm', True)
        PlotClassScores(silhouette_scores[:,3], 'Silhouette', 'spectral', True)
        
        
        PlotClassScores(davies_scores[:,0], 'Davies Bouldin', 'kmeans', True)
        PlotClassScores(davies_scores[:,1], 'Davies Bouldin', 'birch', True)
        PlotClassScores(davies_scores[:,2], 'Davies Bouldin', 'gmm', True)
        PlotClassScores(davies_scores[:,3], 'Davies Bouldin', 'spectral', True)
        
        CrossClusterPlots(np.mean(silhouette_scores, axis = 0), 'Silhouette', True)
        CrossClusterPlots(np.mean(davies_scores, axis = 0), 'Davies', True)
        
        # Compute the linkage matrix
        linkage_matrix = linkage(davies_scores.T, method='ward')  # You can choose a different method if needed
        
        # Plot the dendrogram
        dendrogram(linkage_matrix, labels=["KMeans", "Birch", "GMM", "Spectral"])
        
        plt.title('Dendrogram based on Davies Scores')
        plt.xlabel('Clustering Algorithms')
        plt.ylabel('Distance')
        #plt.show()
        
        # Save plot to a folder
        plt.savefig(f"{self.plot_folder}/dendrogram_Davies_scores_EncodedData.png")
        plt.close()
  
        # Plot the dendrogram
        linkage_matrix = linkage(silhouette_scores.T, method='ward')  # You can choose a different method if needed
        dendrogram(linkage_matrix, labels=["KMeans", "Birch", "GMM", "Spectral"])
        
        plt.title('Dendrogram based on Silhouette Scores')
        plt.xlabel('Clustering Algorithms')
        plt.ylabel('Distance')
        #plt.show()
        
        # Save plot to a folder
        plt.savefig(f"{self.plot_folder}/dendrogram_Silhouette_scores_EncodedData.png")
        plt.close()
        
        # Save results after encoding
        self.save_clustering_results(silhouette_scores, davies_scores, "after")
        
        messagebox.showinfo("Results", "Clustering results can be displayed.")
        
        # Close the main application window
        self.master.destroy()
    

        # Open a new window for displaying results
        self.result_window = tk.Tk()
        self.result_window.title("Clustering Results")
        self.result_window.iconbitmap("logo_image.ico")
        
        width = self.result_window.winfo_screenwidth()
        height = self.result_window.winfo_screenheight()
        
        self.result_window.geometry("%dx%d" % (width, height))
        self.result_window.configure(bg="#f0f0f0")
        self.result_window.option_add("*Font", "Helvetica 10")
        self.result_window.option_add("*Button.Background", "#4CAF50")
        self.result_window.option_add("*Button.Foreground", "#ffffff")
        self.result_window.state("zoomed")
        
        # Load background image
        background_image = Image.open("background_img.jpg").resize((width, height), Image.LANCZOS)
        self.background_photo = ImageTk.PhotoImage(background_image)
        
        # Create a label to hold the background image
        self.background_label = tk.Label(image=self.background_photo)
        self.background_label.place(relwidth=1, relheight=1)
        
        # Create labels to indicate Before and After encoding
        tk.Label(self.result_window, text="Before encoding", font=('Helvetica', 12)).grid(row=8, column=0, pady=10)
        tk.Label(self.result_window, text="After encoding", font=('Helvetica', 12)).grid(row=8, column=2, pady=10)
    
        # Create buttons to display different results
        btn_elbow = tk.Button(self.result_window, text="Elbow Plot", command=self.display_elbow_plot)
        btn_elbow.grid(row=0, column=0, pady=10, padx=10)

        btn_clusters = tk.Button(self.result_window, text="Clusters Plot", command=self.display_clusters_plot)
        btn_clusters.grid(row=0, column=1, pady=10, padx=10)

        btn_silhouette_kmeans = tk.Button(self.result_window, text="Silhouette kmeans Plot", command=self.display_silhouette_kmeans_plot)
        btn_silhouette_kmeans.grid(row=1, column=0, pady=10, padx=10)

        btn_silhouette_birch = tk.Button(self.result_window, text="Silhouette birch Plot", command=self.display_silhouette_birch_plot)
        btn_silhouette_birch.grid(row=1, column=1, pady=10, padx=10)

        btn_silhouette_spectral = tk.Button(self.result_window, text="Silhouette spectral Plot", command=self.display_silhouette_spectral_plot)
        btn_silhouette_spectral.grid(row=1, column=2, pady=10, padx=10)

        btn_silhouette_gmm = tk.Button(self.result_window, text="Silhouette gmm Plot", command=self.display_silhouette_gmm_plot)
        btn_silhouette_gmm.grid(row=1, column=3, pady=10, padx=10)

        btn_davies_bouldin_kmeans = tk.Button(self.result_window, text="Davies Bouldin kmeans Plot", command=self.display_davies_bouldin_kmeans_plot)
        btn_davies_bouldin_kmeans.grid(row=2, column=0, pady=10, padx=10)

        btn_davies_bouldin_birch = tk.Button(self.result_window, text="Davies Bouldin birch Plot", command=self.display_davies_bouldin_birch_plot)
        btn_davies_bouldin_birch.grid(row=2, column=1, pady=10, padx=10)

        btn_davies_bouldin_spectral = tk.Button(self.result_window, text="Davies Bouldin spectral Plot", command=self.display_davies_bouldin_spectral_plot)
        btn_davies_bouldin_spectral.grid(row=2, column=2, pady=10, padx=10)

        btn_davies_bouldin_gmm = tk.Button(self.result_window, text="Davies Bouldin gmm Plot", command=self.display_davies_bouldin_gmm_plot)
        btn_davies_bouldin_gmm.grid(row=2, column=3, pady=10, padx=10)

        btn_cross_clusters_silhouette = tk.Button(self.result_window, text="Cross Clusters Silhouette Plot", command=self.display_cross_clusters_silhouette_plot)
        btn_cross_clusters_silhouette.grid(row=3, column=0, pady=10, padx=10)

        btn_cross_clusters_davies = tk.Button(self.result_window, text="Cross Clusters Davies Bouldin Plot", command=self.display_cross_clusters_davies_plot)
        btn_cross_clusters_davies.grid(row=3, column=1, pady=10, padx=10)

        btn_dendrogram_silhouette = tk.Button(self.result_window, text="dendrogram Silhouette", command=self.display_dendrogram_silhouette)
        btn_dendrogram_silhouette.grid(row=4, column=0, pady=10, padx=10)

        btn_dendrogram_davies = tk.Button(self.result_window, text="dendrogram Davies Bouldin", command=self.display_dendrogram_davies)
        btn_dendrogram_davies.grid(row=4, column=1, pady=10, padx=10)
        
        
        
        # Keep the result window open
        self.result_window.mainloop()
    
        

if __name__ == "__main__":
    root = tk.Tk()
    app = ClusteringApp(root)
    root.mainloop()

